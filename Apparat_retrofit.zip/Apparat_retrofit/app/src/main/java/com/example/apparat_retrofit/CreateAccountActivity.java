package com.example.apparat_retrofit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class CreateAccountActivity extends AppCompatActivity  {
    TextView back,createaccount,enteremail,enterpassword,entername;
    AppCompatImageView backicon;
    TextInputLayout textInputLayoutemail,textInputLayoutpassword,textInputLayoutname;
    TextInputEditText textInputEditTextemail,textInputEditTextpassword,textInputEditTextname;
    Button register;
    ConstraintLayout constraintLayout;
    private static final String TAG ="CreateAccountActivity";
    private RegisterApi registerApi;
    private Disposable disposable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        textInputLayoutname=findViewById(R.id.textinputlayout_create_name);
        textInputLayoutpassword=findViewById(R.id.textinputlayout_create_password);
        textInputLayoutemail=findViewById(R.id.textinputlayout_create_email);

        textInputEditTextname=findViewById(R.id.et_dialogEdit_name);
        textInputEditTextpassword=findViewById(R.id.et_dialogEdit_password);
        textInputEditTextemail=findViewById(R.id.et_dialogEdit_email);

        register=findViewById(R.id.btn_create_continiue);
        constraintLayout=findViewById(R.id.constraintlayout);
        back=findViewById(R.id.tv_create);
        createaccount=findViewById(R.id.tv_create_title);
        entername=findViewById(R.id.tv_create_subtitle_name);
        enteremail=findViewById(R.id.tv_create_subtitle);
        enterpassword=findViewById(R.id.tv_create_subtitle_password);
        backicon=findViewById(R.id.img_back_create);
        registerApi=new RegisterApi(this,TAG);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Validate(textInputEditTextname) && Validate(textInputEditTextpassword) && Validate(textInputEditTextemail)){
                    registerMe();
                }


            }
        });

    }

    private void registerMe(){
        String name=textInputEditTextname.getText().toString().trim();
        String password=textInputEditTextpassword.getText().toString().trim();
        String email=textInputEditTextemail.getText().toString().trim();
        registerApi.getregister(name,password,email).subscribeOn(Schedulers.io()).
                observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<UserRegister>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {
                        disposable=d;

                    }

                    @Override
                    public void onSuccess(@NonNull UserRegister userRegister) {
                        Intent i=new Intent(CreateAccountActivity.this,LoginActivity.class);
                        startActivity(i);

                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Toast.makeText(CreateAccountActivity.this, "One thing wrong", Toast.LENGTH_SHORT).show();

                    }
                });


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(disposable!=null){
            disposable.dispose();
        }
    }

    public boolean Validate(TextInputEditText editText){
        if(editText.getText().toString().trim().length()>0){
            return true;
        }
        editText.setError("Please Fill This");
        editText.requestFocus();
        return false;




    }

}
