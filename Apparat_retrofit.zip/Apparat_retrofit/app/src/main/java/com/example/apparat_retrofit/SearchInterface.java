package com.example.apparat_retrofit;

import io.reactivex.Single;
import retrofit2.http.GET;

public interface SearchInterface {

    @GET("/etc/api/categoryVideos/cat/15/perpage/10")
    Single<UserListResponse> getSearchList();



}
