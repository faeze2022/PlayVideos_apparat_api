package com.example.apparat_retrofit;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HomeFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener,UsersAdapter.MyOnItemClickListener {

    RecyclerView recyclerView;
    UserListResponse userListResponseData;
    SwipeRefreshLayout refreshLayout;
    private Disposable disposable;
    private Api api;
    private static final String TAG = "HomeFragment";
    public static String Extra_title="title";
    public static String Extra_visit="visit_cnt";
    public static String Extra_frame="frame";



    public HomeFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       setHasOptionsMenu(true);//Add this sentence to the menu


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Toolbar  mToolbarContact;
        setHasOptionsMenu(true);


        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        mToolbarContact = view.findViewById(R.id.toolbar);
       // mToolbarContact.inflateMenu(R.menu.main_menu);
        recyclerView=view.findViewById(R.id.recycle_home_frag);
       //swipeRefreshLayout=view.findViewById(R.id.swiprefresh_home_frag);
        refreshLayout=view.findViewById(R.id.refresh_home);
        api=new Api(this,TAG);


        mToolbarContact .setTitle("آپارات");
        mToolbarContact.setTitleTextColor(ContextCompat.getColor(getActivity(), R.color.colorwhite));
        //getActionBar().setDisplayHomeAsUpEnabled(true);

        mToolbarContact.inflateMenu(R.menu.main_menu);


        ((AppCompatActivity) getActivity()).setSupportActionBar(mToolbarContact);
        mToolbarContact.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent search=new Intent(getActivity(),SearchActivity.class);
                startActivity(search);
            }
        });
        mToolbarContact.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.icon_search:
                        Intent search=new Intent(getActivity(),SearchActivity.class);
                        startActivity(search);

                        // do what ever you want here
                }
                return true;

            }
        });











        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getUserListData();
        return view;

    }

    private void  getUserListData(){


        // Api is a class in which we define a method getClient() that returns the API Interface class object
        // getUsersList() is a method in API Interface class, in this method we define our API sub url
        api.getUsersList().subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new SingleObserver<UserListResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable=d;

                    }

                    @Override
                    public void onSuccess(UserListResponse userListResponses) {
                        // setDataInRecyclerView();
                        userListResponseData=userListResponses;
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(linearLayoutManager);
                        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
                        recyclerView.setHasFixedSize(true);
                        UsersAdapter usersAdapter=new UsersAdapter(userListResponseData,(UsersAdapter.MyOnItemClickListener)HomeFragment.this,getActivity());
                        usersAdapter.notifyDataSetChanged();
                        recyclerView.setAdapter(usersAdapter);

                    }

                    @Override
                    public void onError(Throwable e) {
                        Toast.makeText(getContext(), "خطای نامشخص", Toast.LENGTH_SHORT).show();

                    }
                });






    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(disposable!=null){
            disposable.dispose();


        }
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        //menu.clear(); / / this sentence is useless. You don't need to add it
        menu.clear();
        inflater.inflate(R.menu.main_menu, menu);
    }




    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.toolbar_menu:
                Toast.makeText(getContext(), "You clicked menu", Toast.LENGTH_SHORT).show();
                ((AppCompatActivity) getActivity()) .getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                ((AppCompatActivity) getActivity()) .getSupportActionBar().setHomeButtonEnabled(true);

                break;
            case R.id.toolbar_search:
                Toast.makeText(getContext(), "You clicked search", Toast.LENGTH_SHORT).show();
                Intent search=new Intent(getActivity(),SearchActivity.class);
                startActivity(search);
                break;
        }
        return true;



    }

    @Override
    public void onRefresh() {
        Toast.makeText(getActivity(), "Refresh", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshLayout.setRefreshing(false);
            }
        }, 2000);
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        return false;
    }

    @Override
    public void OnItemClick(int position) {

    }
}
