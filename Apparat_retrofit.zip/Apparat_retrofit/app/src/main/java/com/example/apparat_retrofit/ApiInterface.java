package com.example.apparat_retrofit;

import java.util.List;

import io.reactivex.Single;
import retrofit2.Call;
import retrofit2.http.GET;


public interface ApiInterface {
@GET("/etc/api/categoryVideos/cat/15/perpage/10")
Single<UserListResponse> getUsersList();


}


 //jsonsyntaxexception java.lang.illegalstateexception expected begin_object site:stackoverflow.com
//retrofit Error:301 moved permanently
//E/RecyclerView: No adapter attached; skipping layout
//java.lang.IllegalStateException: Expected BEGIN_ARRAY but was BEGIN_OBJECT at line 1 column 2 path $

/*
Caused by: java.lang.IllegalStateException: Expected BEGIN_ARRAY but was BEGIN_OBJECT at line 1 column 2 [duplicate]
 */
//: https://play.googleapis.com/play/log?format=raw&proto_v2=true




