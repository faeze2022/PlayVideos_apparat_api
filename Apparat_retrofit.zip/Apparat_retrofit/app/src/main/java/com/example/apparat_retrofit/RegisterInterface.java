package com.example.apparat_retrofit;

import com.google.gson.JsonObject;

import io.reactivex.Single;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.POST;

public interface RegisterInterface {

    @POST("simpleregister.php")
    Single<UserRegister> getregister(@Body JsonObject body);

}

