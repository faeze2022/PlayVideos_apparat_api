package com.example.apparat_retrofit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {
    private Context context;
    UserListResponse userListResponseData;
    //private List<UserListResponse.Categoryvideos> lstlist;
    private SearchAdapterListener listener;

    public SearchAdapter(Context context, UserListResponse userListResponseData,SearchAdapterListener listener) {
        this.context = context;
        this.userListResponseData = userListResponseData;
        this.listener=listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_home, parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UserListResponse.Categoryvideos homemodel=userListResponseData.getCategoryvideos().get(position);

        holder.titleTexthome.setText(homemodel.getTitle());
        holder.sdateTexthome.setText(homemodel.getSdate());
        holder.visitcntTexthome.setText("بازدید: "+String.valueOf(homemodel.getVisit_cnt()));
        holder.durationTexthome.setText("مدت زمان: ثانیه "+String.valueOf(homemodel.getDuration()));
        Glide.with(holder.smallposterImagehome.getContext()).load(homemodel.getSmall_poster()).into(holder.smallposterImagehome);

    }

    @Override
    public int getItemCount() {
        return userListResponseData.getCategoryvideos().size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        public CardView HomeCardview;
        public ImageView smallposterImagehome;
        public TextView titleTexthome;
        public TextView sdateTexthome;
        public TextView visitcntTexthome;
        public TextView durationTexthome;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            HomeCardview=itemView.findViewById(R.id.card_item_home);
            smallposterImagehome=itemView.findViewById(R.id.img_home_smallposter);
            titleTexthome=itemView.findViewById(R.id.tv_home_title);
            sdateTexthome=itemView.findViewById(R.id.tv_home_sdate);
            visitcntTexthome=itemView.findViewById(R.id.tv_home_visitcnt);
            durationTexthome=itemView.findViewById(R.id.tv_home_duration);
        }
    }

      public interface SearchAdapterListener {
        void onsearchSelected(UserListResponse userlistresponse);
    }












}
