package com.example.apparat_retrofit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class SearchActivity extends AppCompatActivity implements SearchAdapter.SearchAdapterListener {
    Toolbar toolbar;
    ImageView img;
    EditText inputsearch;
    RecyclerView rv;
    private SearchApi apisearch;
    private SearchAdapter searchAdapter;
    private static final String TAG = "SearchActivity";
    UserListResponse userListResponseData;
    Disposable disposable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        toolbar=findViewById(R.id.toolbar);
        img=findViewById(R.id.icon_search);
        inputsearch=findViewById(R.id.input_search);
        rv=findViewById(R.id.rv_search);
        apisearch=new SearchApi(this,TAG);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        searchAdapter=new SearchAdapter(this,userListResponseData,(SearchAdapter.SearchAdapterListener)this );



         RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
         rv.setLayoutManager(mLayoutManager);
         rv.setItemAnimator(new DefaultItemAnimator());
         rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
         rv.setAdapter(searchAdapter);

         apisearch.getSearchList().subscribeOn(Schedulers.io())
                 .subscribeOn(AndroidSchedulers.mainThread())
                 .subscribe(new SingleObserver<UserListResponse>() {
                     @Override
                     public void onSubscribe(@NonNull Disposable d) {
                         disposable=d;


                     }

                     @Override
                     public void onSuccess(@NonNull UserListResponse userListResponse) {
                         searchAdapter.notifyDataSetChanged();


                     }

                     @Override
                     public void onError(@NonNull Throwable e) {
                         Log.e(TAG, "onError: " + e.getMessage());

                     }
                 });









    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(disposable!=null){
            disposable.dispose();


        }
    }

    @Override
    public void onsearchSelected(UserListResponse userlistresponse) {

    }
}