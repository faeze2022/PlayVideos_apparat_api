package com.example.apparat_retrofit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity{
    Toolbar logintoolbar;
    AppCompatImageView forward;
    TextView tx1,tx2,tx3;
    Button create,login;
    View viewlogin;
    TextInputLayout textInputLayoutemail,textInputLayoutpassword;
    TextInputEditText textInputEditTextemail,textInputEditTextpassword;

    ConstraintLayout constraintLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        logintoolbar=findViewById(R.id.toolbar_login);
        forward=findViewById(R.id.img_login_forward);
        tx1=findViewById(R.id.tv_login);
        tx2=findViewById(R.id.tv_login_two);
        tx3=findViewById(R.id.tv_login_tree);
        create=findViewById(R.id.btn_login_creat);

        viewlogin=findViewById(R.id.view_login);
        textInputLayoutemail=findViewById(R.id.textinputlayout_email);
        textInputLayoutpassword=findViewById(R.id.textinputlayout_password);
        textInputEditTextemail=findViewById(R.id.et_dialogEdit_email);
        textInputEditTextpassword=findViewById(R.id.et_dialogEdit_password);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent r=new Intent(LoginActivity.this,CreateAccountActivity.class);
                startActivity(r);
            }
        });







    }








}
