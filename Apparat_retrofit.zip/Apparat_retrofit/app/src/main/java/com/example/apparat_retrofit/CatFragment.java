package com.example.apparat_retrofit;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class CatFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER


    public CatFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar cattoolar;
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_cat, container, false);
        Button searchbtn;
        TextView game,sport,art,music;
        searchbtn=view.findViewById(R.id.btn_search);
        game=view.findViewById(R.id.tv_game);
        sport=view.findViewById(R.id.tv_sports);
        art=view.findViewById(R.id.tv_art);
        music=view.findViewById(R.id.tv_music);
        game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(),GameActivity.class);
                startActivity(i);

            }
        });

        sport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sintent=new Intent(getActivity(),SportActivity.class);
                startActivity(sintent);
            }
        });
        art.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent aintent=new Intent(getActivity(),ArtActivity.class);
                startActivity(aintent);
            }
        });
        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent searchintent=new Intent(getActivity(),SearchActivity.class);
                startActivity(searchintent);
            }
        });



        setHasOptionsMenu(true);
        cattoolar=view.findViewById(R.id.toolbar);
        cattoolar .setTitle("آپارات");
        cattoolar.setTitleTextColor(ContextCompat.getColor(getActivity(), R.color.colorwhite));

        ((AppCompatActivity) getActivity()).setSupportActionBar(cattoolar);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.main_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.toolbar_search:
                Intent intents=new Intent(getActivity(),SearchActivity.class);
                startActivity(intents);
                break;
            case R.id.toolbar_menu:
                Toast.makeText(getContext(), "You clicked menu", Toast.LENGTH_SHORT).show();
                ((AppCompatActivity) getActivity()) .getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                ((AppCompatActivity) getActivity()) .getSupportActionBar().setHomeButtonEnabled(true);

                break;

        }
        return true;
    }
}
